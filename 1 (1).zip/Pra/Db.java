import java.sql.*;
import java.util.*;

class U_N
{   
    String url = "jdbc:mysql://localhost:3306/check";
    String user = "root";
    String password = "";
    Scanner sc = new Scanner(System.in);
    U_N()
    {    
        
    }
}

class Cases extends U_N
{   
    Cases()
    {  int a = 0;
        while (a != 7)
        {   System.out.println("------------ Menu For CRUD ---------------");
            System.out.println("1. Check Connection");
            System.out.println("2. Create Table");
            System.out.println("3. Insert Data");
            System.out.println("4. Update Data");
            System.out.println("5. Show Data");
            System.out.println("6. Delete Data");
            System.out.println("7. Exits");
            System.out.println("------------------------------------------");
            System.out.print("Enter Above Choice :-");
            a = sc.nextInt();

            switch (a) 
            {
                case 1:
                    new Check_con();
                    break;

                case 2:
                    new Table();
                    break;
                    
                case 3:
                    new In();
                    break;
 
                case 4:
                    new Up();
                    break;

                case 5:
                    new Display();
                    break;
                
                case 6:
                    new Dlt();
                    break;

                case 7:
                    System.out.println("Exit...");
                    break;
                default:
                    break;
            }
        }
    }
}

class Check_con extends U_N
{
    Check_con()
    {  
        try
        {
            Connection con = DriverManager.getConnection(url,user,password);
            if(con.isClosed())
            {   System.out.println("---------------------");
                System.out.println("Connection Is Closed");
                System.out.println("---------------------");
            }
            else
            {
                System.out.println("------------------------------------");
                System.out.println("Connection Establish Successfully...");
                System.out.println("------------------------------------");
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}

class Table extends U_N
{
    Table()
    {           System.out.print("Enter Table Name :-");
                 String nm = sc.nextLine(); 
        try
        {
            Connection con = DriverManager.getConnection(url,user,password);
            String query = "create table "+nm+"(id int(3) primary key auto_increment, name varchar(50))";
            Statement stmt = con.createStatement();
            stmt.executeUpdate(query);

            System.out.println("------------------------------------------------");
            System.err.println("Table Created Successfully....");
            System.out.println("-------------------------------------------------");

        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}

class In extends U_N
{
    In()
    {
        System.out.print("Enter Name :-");
        String s1=sc.nextLine();    

          try{
              Connection con = DriverManager.getConnection(url, user, password);
              String query = "insert into jv(name) values('"+s1+"')";

              PreparedStatement stmt = con.prepareStatement(query);

              stmt.executeUpdate();
              System.out.println("------------------------------------------------");
              System.out.println("Data inserted Successfully...");
              System.out.println("------------------------------------------------");
          }
          catch(SQLException e)
          {
            e.printStackTrace();
          }
    }
}
class Display extends U_N
{
        Display()
        {
            try{
                Connection con = DriverManager.getConnection(url, user, password);
                String  selectquery = "select * from jv";
                Statement st = con.createStatement();
                ResultSet rs = st.executeQuery(selectquery);
                System.err.println("\tID\t\tNAME");
                while(rs.next())
                {
                    System.err.println("\t"+rs.getInt(1)+"\t\t"+rs.getString(2));
                }
                con.close();
            }
            catch(SQLException e) 
            {
                e.printStackTrace();
            }
        }
}

class Dlt extends U_N
{
    Dlt()
    {
        try
        {
            System.out.print("Enter Id For Delete Record :-");
            int  id=sc.nextInt();
            Connection con = DriverManager.getConnection(url,user,password);
            String q = "delete from jv where id = "+ id + "";

            Statement stmt = con.createStatement();

            stmt.executeUpdate(q);
            System.out.println("---------------------------- ");
            System.out.println("Record Deleted Successfully...");
            System.out.println("-----------------------------");
            con.close();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}

class Up extends U_N
{
    Up()
    {
        try{
            Connection con = DriverManager.getConnection(url, user, password);
            String updatequery = "update jv set name='abc' where id = 3";
            Statement st = con.createStatement();
            st.executeUpdate(updatequery);
            System.out.println("---------------------------- ");
            System.err.println("Data Updated Succesfully...");
            System.out.println("---------------------------- ");
            con.close();
        }
      catch(SQLException e)
      {
         e.printStackTrace();
       }

    }
}
public class Db 
{
    public static void main(String[] args) 
    {
        // Check_con ck = new Check_con();
        Cases cs = new Cases();
        
    }
    
}